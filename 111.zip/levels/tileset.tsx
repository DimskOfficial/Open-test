<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="ocmario" tilewidth="16" tileheight="16" tilecount="13" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="16" height="16" source="../img/block.bmp"/>
 </tile>
 <tile id="1">
  <image width="16" height="16" source="../img/ground.bmp"/>
 </tile>
 <tile id="2">
  <image width="16" height="16" source="../img/hard.bmp"/>
 </tile>
 <tile id="3">
  <image width="16" height="16" source="../img/mystery_used.bmp"/>
 </tile>
 <tile id="4">
  <image width="16" height="16" source="../img/mystery.bmp"/>
 </tile>
 <tile id="5">
  <image width="16" height="16" source="../img/pipe_1.bmp"/>
 </tile>
 <tile id="6">
  <image width="16" height="16" source="../img/pipe_2.bmp"/>
 </tile>
 <tile id="7">
  <image width="16" height="16" source="../img/pipe_3.bmp"/>
 </tile>
 <tile id="8">
  <image width="16" height="16" source="../img/pipe_4.bmp"/>
 </tile>
 <tile id="9">
  <image width="16" height="16" source="../img/goomba_0.bmp"/>
 </tile>
 <tile id="10">
  <image width="16" height="16" source="../img/flag_pole_mid.bmp"/>
 </tile>
 <tile id="11">
  <image width="16" height="16" source="../img/flag_pole_top.bmp"/>
 </tile>
 <tile id="12">
  <image width="16" height="16" source="../img/flag.bmp"/>
 </tile>
</tileset>
